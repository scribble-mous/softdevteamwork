﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoDeal
{
    public partial class Form1 : Form
    {

        int[] Numbers = new int[18]{1, 2, 5, 10, 20, 50, 75, 85, 100, 1000, 2000, 5000, 10000, 25000, 50000, 100000, 150000, 250000};
        int[] Box = new int[18];
        int howmany = 3;

        bool currentboxChosen = false;

        int currentboxValue;



        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void selectBox_click(object sender, EventArgs e)
        {
            
        }

        private void Deal_Click(object sender, EventArgs e)
        {
            if (currentboxChosen == false)
            {
                statustext.Text = ("Please choose a box first!");
            }
            else
            {
                MessageBox.Show("You won" + currentboxValue);
            }
        }

    }
}
